package generic;

import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;

import generic.Operand.OperandType;


public class Simulator {
		
	static FileInputStream inputcodeStream = null;


	public static Map<Instruction.OperationType,String> map = new HashMap<Instruction.OperationType,String>(){{
			put(Instruction.OperationType.add, "00000");
			put(Instruction.OperationType.addi, "00001");
			put(Instruction.OperationType.sub, "00010");
			put(Instruction.OperationType.subi, "00011");
			put(Instruction.OperationType.mul, "00100");
			put(Instruction.OperationType.muli, "00101");
			put(Instruction.OperationType.div, "00110");
			put(Instruction.OperationType.divi, "00111");
			put(Instruction.OperationType.and, "01000");
			put(Instruction.OperationType.andi, "01001");
			put(Instruction.OperationType.or, "01010");
			put(Instruction.OperationType.ori, "01011");
			put(Instruction.OperationType.xor, "01100");
			put(Instruction.OperationType.xori, "01101");
			put(Instruction.OperationType.slt, "01110");
			put(Instruction.OperationType.slti, "01111");
			put(Instruction.OperationType.sll, "10000");
			put(Instruction.OperationType.slli, "10001");
			put(Instruction.OperationType.srl, "10010");
			put(Instruction.OperationType.srli, "10011");
			put(Instruction.OperationType.sra, "10100");
			put(Instruction.OperationType.srai, "10101");
			put(Instruction.OperationType.load, "10110");
			put(Instruction.OperationType.store, "10111");
			put(Instruction.OperationType.jmp, "11000");
			put(Instruction.OperationType.beq, "11001");
			put(Instruction.OperationType.bne, "11010");
			put(Instruction.OperationType.blt, "11011");
			put(Instruction.OperationType.bgt, "11100");
			put(Instruction.OperationType.end, "11101");
	}};

	public static String binaryofint(int val, int size){
		String binaryVal = Integer.toBinaryString(val);
		if(val < 0){
			return binaryVal.substring(32-size);
		}
		
		String zeros = "%0" + Integer.toString(size) + "d";
		binaryVal = String.format(zeros,Integer.parseInt(binaryVal));
		return binaryVal;
	}
	
	public static String ConvertLabelled(Operand obj, int bitlen){
		if(obj == null) return binaryofint(0, bitlen);
		if(obj.getOperandType() == OperandType.Label){
			return binaryofint(ParsedProgram.symtab.get(obj.getLabelValue()), bitlen);
		}
		return binaryofint(obj.value, bitlen);
	}

	public static void setupSimulation(String assemblyProgramFile)
	{	
		int firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
		ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
		ParsedProgram.printState();
	}
	
	public static void assemble(String objectProgramFile)
	{
		//TODO your assembler code
		//1. open the objectProgramFile in binary mode
		//2. write the firstCodeAddress to the file
		//3. write the data to the file
		//4. assemble one instruction at a time, and write to the file
		//5. close the file

		try {
			FileOutputStream file = new FileOutputStream(objectProgramFile);

			byte [] codeAddress = ByteBuffer.allocate(4).putInt(ParsedProgram.firstCodeAddress).array();
			try {
				file.write(codeAddress);
			} catch (IOException e) {

				e.printStackTrace();
			}

			for(int i = 0; i < ParsedProgram.data.size(); i++){
				// System.out.println(ParsedProgram.data.get(i));
				byte [] data = ByteBuffer.allocate(4).putInt(ParsedProgram.data.get(i)).array();
				try {
					file.write(data);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			for (int i = 0; i < ParsedProgram.code.size(); i++) {
			
				String binary = map.get(ParsedProgram.code.get(i).getOperationType());
				int optcode = Integer.parseInt(binary,2);
				if( optcode <= 20 && optcode%2 == 0){
					binary += ConvertLabelled(ParsedProgram.code.get(i).sourceOperand1, 5);
					binary += ConvertLabelled(ParsedProgram.code.get(i).sourceOperand2, 5);
					binary += ConvertLabelled(ParsedProgram.code.get(i).destinationOperand, 5);
					binary += binaryofint(0, 12);
					// System.out.println(binary);
				}
				else if(optcode == 24){
					if(ParsedProgram.code.get(i).destinationOperand.getOperandType() == Operand.OperandType.Register){
						// binary += binaryofint(ParsedProgram.code.get(i).destinationOperand.value, 5);
						binary += ConvertLabelled(ParsedProgram.code.get(i).destinationOperand, 5);
						// System.out.println("if register");
						// System.out.println(binary);
						binary += binaryofint(0, 22);
						
					}
					else{
						binary += binaryofint(0, 5);
						// System.out.println("else 10");
						// System.out.println(binary);
						// int val = ParsedProgram.code.get(i).destinationOperand.value - ParsedProgram.code.get(i).programCounter;
						// binary += binaryofint(val, 22);
						Integer immediate = Integer.parseInt(ConvertLabelled(ParsedProgram.code.get(i).destinationOperand,22),2) - ParsedProgram.code.get(i).programCounter;
						// System.out.println(binary);
						binary += binaryofint(immediate, 22);
					}
					// binary += binaryofint(ParsedProgram.code.get(i).destinationOperand.value, 5);
					// String labelval = ParsedProgram.code.get(i).destinationOperand.labelValue;
					// Integer labeladdr = ParsedProgram.symtab.get(labelval);
					// System.out.println(ParsedProgram.getInstructionAt(labeladdr));
					// System.out.println();
				}
				else if(optcode == 29){
					binary += binaryofint(0,27);
				}
				else{
					if(optcode >= 25 && optcode <= 28){
						binary += ConvertLabelled(ParsedProgram.code.get(i).sourceOperand1, 5);
						binary += ConvertLabelled(ParsedProgram.code.get(i).sourceOperand2, 5);
						// System.out.println("binary till 15 "+binary);
						// System.out.println(ParsedProgram.code.get(i).programCounter);
						// System.out.println(Integer.parseInt(ConvertLabelled(ParsedProgram.code.get(i).destinationOperand,17),2));
						Integer immediate = Integer.parseInt(ConvertLabelled(ParsedProgram.code.get(i).destinationOperand,17),2) - ParsedProgram.code.get(i).programCounter;
						// System.out.println(immediate);
						binary += binaryofint(immediate, 17);
						// System.out.println("binary till 32 "+binary);
					}
					else{
						binary += ConvertLabelled(ParsedProgram.code.get(i).sourceOperand1, 5);
						binary += ConvertLabelled(ParsedProgram.code.get(i).destinationOperand, 5);
						binary += ConvertLabelled(ParsedProgram.code.get(i).sourceOperand2, 17);
					}
					
				}
				byte [] data = ByteBuffer.allocate(4).putInt((int)Long.parseLong(binary,2)).array();

				// System.out.println(binary);
				try {
					file.write(data);
				} catch (IOException e) {
					e.printStackTrace();
				}

				

			}

			try {
				file.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		
		

	}
	
}
